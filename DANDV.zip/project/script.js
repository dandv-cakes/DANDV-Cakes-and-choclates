// WhatsApp Configuration
const WHATSAPP_NUMBER = '+919586386501'; // Replace with your actual WhatsApp number

// Global variables
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let currentTestimonial = 0;
let isLoading = true;

// Sample data
const products = [
    {
        id: 1,
        name: "Chocolate Delight Cake",
        price: 45.99,
        category: "cakes",
        image: "https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Rich chocolate cake with layers of creamy ganache",
        badge: "Bestseller"
    },
    {
        id: 2,
        name: "Vanilla Dream Cake",
        price: 39.99,
        category: "cakes",
        image: "https://images.pexels.com/photos/140831/pexels-photo-140831.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Classic vanilla cake with buttercream frosting",
        badge: "Popular"
    },
    {
        id: 3,
        name: "Strawberry Bliss",
        price: 42.99,
        category: "cakes",
        image: "https://images.pexels.com/photos/827513/pexels-photo-827513.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Fresh strawberry cake with whipped cream",
        badge: "Seasonal"
    },
    {
        id: 4,
        name: "Premium Chocolate Box",
        price: 29.99,
        category: "chocolates",
        image: "https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Assorted premium chocolates in elegant packaging",
        badge: "Gift Box"
    },
    {
        id: 5,
        name: "Dark Chocolate Truffles",
        price: 24.99,
        category: "chocolates",
        image: "https://images.pexels.com/photos/3622643/pexels-photo-3622643.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Handcrafted dark chocolate truffles with ganache",
        badge: "Artisan"
    },
    {
        id: 6,
        name: "French Macarons",
        price: 18.99,
        category: "pastries",
        image: "https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Colorful French macarons with various flavors",
        badge: "French"
    },
    {
        id: 7,
        name: "Croissant Selection",
        price: 15.99,
        category: "pastries",
        image: "https://images.pexels.com/photos/2135677/pexels-photo-2135677.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Fresh buttery croissants, plain and chocolate",
        badge: "Fresh Daily"
    },
    {
        id: 8,
        name: "Wedding Cake Deluxe",
        price: 199.99,
        category: "cakes",
        image: "https://images.pexels.com/photos/1070850/pexels-photo-1070850.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Three-tier wedding cake with custom decoration",
        badge: "Custom"
    },
    {
        id: 9,
        name: "Milk Chocolate Hearts",
        price: 19.99,
        category: "chocolates",
        image: "https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg?auto=compress&cs=tinysrgb&w=500",
        description: "Heart-shaped milk chocolates, perfect for gifts",
        badge: "Romantic"
    }
];

const testimonials = [
    {
        name: "Sarah Johnson",
        image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100",
        text: "The best cakes I've ever tasted! D&V creates pure magic with their recipes. Every bite is a celebration!",
        role: "Happy Customer",
        rating: 5
    },
    {
        name: "Michael Chen",
        image: "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=100",
        text: "Their chocolates are absolutely divine. The quality and taste exceed all expectations. Highly recommended!",
        role: "Chocolate Lover",
        rating: 5
    },
    {
        name: "Emily Rodriguez",
        image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100",
        text: "D&V made our wedding cake dreams come true. Not only beautiful but incredibly delicious!",
        role: "Bride",
        rating: 5
    },
    {
        name: "David Wilson",
        image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100",
        text: "Professional service and amazing products. They never disappoint and always deliver on time!",
        role: "Event Planner",
        rating: 5
    }
];

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the app
    initializeApp();
});

function initializeApp() {
    // Show loading animation
    setTimeout(() => {
        hideLoader();
        initializeComponents();
    }, 2500);
}

function hideLoader() {
    const loader = document.getElementById('loader');
    loader.classList.add('hidden');
    setTimeout(() => {
        loader.style.display = 'none';
    }, 500);
}

function initializeComponents() {
    setupNavigation();
    setupScrollAnimations();
    loadProducts();
    loadTestimonials();
    setupContactForm();
    setupCartFunctionality();
    setupScrollEffects();
    
    // Add stagger animation to hero elements
    animateHeroElements();
}

// Navigation Setup
function setupNavigation() {
    const navbar = document.getElementById('navbar');
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Mobile menu toggle
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on links
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Smooth scroll for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Update active nav link on scroll
    window.addEventListener('scroll', updateActiveNavLink);
}

function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 150;
        const sectionHeight = section.offsetHeight;
        
        if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
}

// Scroll Animations
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                
                // Add stagger effect for cards
                if (entry.target.classList.contains('about-card')) {
                    const cards = entry.target.parentElement.querySelectorAll('.about-card');
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.style.animation = `fadeInUp 0.6s ease-out forwards`;
                            card.style.animationDelay = `${index * 0.2}s`;
                        }, index * 100);
                    });
                }
            }
        });
    }, observerOptions);

    // Add scroll reveal class to elements
    const revealElements = document.querySelectorAll('.about-card, .product-card, .contact-card, .testimonial-slide');
    revealElements.forEach(el => {
        el.classList.add('scroll-reveal');
        observer.observe(el);
    });
}

// Product Loading and Filtering
function loadProducts() {
    const productsGrid = document.getElementById('products-grid');
    const filterButtons = document.querySelectorAll('.filter-btn');

    function renderProducts(productsToShow = products) {
        productsGrid.innerHTML = '';
        
        productsToShow.forEach((product, index) => {
            const productCard = createProductCard(product, index);
            productsGrid.appendChild(productCard);
        });

        // Animate product cards
        setTimeout(() => {
            const cards = productsGrid.querySelectorAll('.product-card');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.animation = 'fadeInUp 0.6s ease-out forwards';
                }, index * 100);
            });
        }, 100);
    }

    function createProductCard(product, index) {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        card.innerHTML = `
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" class="product-img">
                <div class="product-overlay">
                    <div class="product-overlay-buttons">
                        <button class="add-to-cart" onclick="addToCart(${product.id})">
                            <i class="fas fa-shopping-cart"></i>
                            Add to Cart
                        </button>
                        <button class="view-details" onclick="viewProduct(${product.id})">
                            <i class="fas fa-eye"></i>
                            View Details
                        </button>
                    </div>
                </div>
                ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
            </div>
            <div class="product-info">
                <h3 class="product-name" onclick="viewProduct(${product.id})">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-price">₹${product.price}</div>
            </div>
        `;

        return card;
    }

    // Filter functionality
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Update active button
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // Filter products
            const filter = this.getAttribute('data-filter');
            let filteredProducts = products;

            if (filter !== 'all') {
                filteredProducts = products.filter(product => product.category === filter);
            }

            renderProducts(filteredProducts);
        });
    });

    // Initial render
    renderProducts();
}

function viewProduct(productId) {
    window.location.href = `product-detail.html?id=${productId}`;
}

// Testimonials Slider
function loadTestimonials() {
    const slider = document.getElementById('testimonials-slider');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');

    function createTestimonialSlide(testimonial) {
        const slide = document.createElement('div');
        slide.className = 'testimonial-slide';
        
        slide.innerHTML = `
            <div class="testimonial-text">"${testimonial.text}"</div>
            <div class="testimonial-author">
                <img src="${testimonial.image}" alt="${testimonial.name}" class="author-avatar">
                <div class="author-info">
                    <h4>${testimonial.name}</h4>
                    <p>${testimonial.role}</p>
                    <div class="rating">
                        ${'<i class="fas fa-star"></i>'.repeat(testimonial.rating)}
                    </div>
                </div>
            </div>
        `;

        return slide;
    }

    function renderTestimonials() {
        slider.innerHTML = '';
        testimonials.forEach((testimonial, index) => {
            const slide = createTestimonialSlide(testimonial);
            if (index === currentTestimonial) {
                slide.classList.add('active');
            }
            slider.appendChild(slide);
        });
    }

    function showTestimonial(index) {
        const slides = slider.querySelectorAll('.testimonial-slide');
        slides.forEach(slide => slide.classList.remove('active'));
        
        if (slides[index]) {
            slides[index].classList.add('active');
            currentTestimonial = index;
        }
    }

    function nextTestimonial() {
        const nextIndex = (currentTestimonial + 1) % testimonials.length;
        showTestimonial(nextIndex);
    }

    function prevTestimonial() {
        const prevIndex = (currentTestimonial - 1 + testimonials.length) % testimonials.length;
        showTestimonial(prevIndex);
    }

    // Event listeners
    nextBtn.addEventListener('click', nextTestimonial);
    prevBtn.addEventListener('click', prevTestimonial);

    // Auto-slide
    setInterval(nextTestimonial, 5000);

    // Initial render
    renderTestimonials();
}

// Contact Form
function setupContactForm() {
    const form = document.getElementById('contact-form');
    const inputs = form.querySelectorAll('input, textarea');

    // Add floating label effect
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });

        // Check if input has value on load
        if (input.value) {
            input.parentElement.classList.add('focused');
        }
    });

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const name = formData.get('name');
        const email = formData.get('email');
        const phone = formData.get('phone');
        const message = formData.get('message');

        // Simulate form submission
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        submitBtn.disabled = true;

        setTimeout(() => {
            submitBtn.innerHTML = '<i class="fas fa-check"></i> Message Sent!';
            submitBtn.style.background = '#4CAF50';
            
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                submitBtn.style.background = '';
                form.reset();
                inputs.forEach(input => {
                    input.parentElement.classList.remove('focused');
                });
            }, 2000);
        }, 1500);
    });
}

// Shopping Cart
function setupCartFunctionality() {
    const cartIcon = document.getElementById('cart-icon');
    const cartSidebar = document.getElementById('cart-sidebar');
    const closeCart = document.getElementById('close-cart');
    const overlay = document.getElementById('overlay');

    cartIcon.addEventListener('click', openCart);
    closeCart.addEventListener('click', closeCartSidebar);
    overlay.addEventListener('click', closeCartSidebar);

    function openCart() {
        cartSidebar.classList.add('open');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeCartSidebar() {
        cartSidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Initialize cart display
    updateCartDisplay();
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }

    updateCartDisplay();
    localStorage.setItem('cart', JSON.stringify(cart));
    showCartNotification(product.name);
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartDisplay();
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (!item) return;

    item.quantity += change;
    
    if (item.quantity <= 0) {
        removeFromCart(productId);
    } else {
        updateCartDisplay();
    }
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartDisplay() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    cartCount.style.display = totalItems > 0 ? 'flex' : 'none';

    // Update cart items
    cartItems.innerHTML = '';
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 2rem;">Your cart is empty</p>';
    } else {
        cart.forEach(item => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">₹${item.price}</div>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    </div>
                </div>
                <button class="remove-item" onclick="removeFromCart(${item.id})">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            cartItems.appendChild(cartItem);
        });
    }

    // Update total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = total.toFixed(2);
}

function checkoutViaWhatsApp() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    let message = `🛒 *Order Summary from D&V Cakes & Chocolates*\n\n`;
    let total = 0;
    
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        message += `${index + 1}. *${item.name}*\n`;
        message += `   🔢 Quantity: ${item.quantity}\n`;
        message += `   💰 Price: ₹${item.price} each\n`;
        message += `   💵 Subtotal: ₹${itemTotal.toFixed(2)}\n\n`;
    });
    
    message += `💵 *Total Amount: ₹${total.toFixed(2)}*\n\n`;
    message += `📞 *Customer Details:*\n`;
    message += `Please provide your:\n`;
    message += `• Full Name\n`;
    message += `• Delivery Address\n`;
    message += `• Phone Number\n`;
    message += `• Preferred Delivery Date & Time\n\n`;
    message += `Thank you for choosing D&V Cakes & Chocolates! 🎂✨`;

    const whatsappURL = `https://wa.me/₹{WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, '_blank');
}

function showCartNotification(productName) {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: var(--gradient-primary);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: var(--shadow-medium);
        z-index: 10002;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        font-weight: 500;
    `;
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        ${productName} added to cart!
    `;

    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);

    // Animate out and remove
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Hero Animation
function animateHeroElements() {
    const heroTitle = document.querySelector('.hero-title');
    const heroTagline = document.querySelector('.hero-tagline');
    const heroDescription = document.querySelector('.hero-description');
    const heroButtons = document.querySelector('.hero-buttons');
    const productShowcase = document.querySelector('.product-showcase');

    // Reset animations
    [heroTagline, heroDescription, heroButtons].forEach(el => {
        if (el) {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
        }
    });

    // Animate elements with delay
    setTimeout(() => {
        if (heroTagline) {
            heroTagline.style.animation = 'fadeInUp 1s ease-out forwards';
        }
    }, 800);

    setTimeout(() => {
        if (heroDescription) {
            heroDescription.style.animation = 'fadeInUp 1s ease-out forwards';
        }
    }, 1000);

    setTimeout(() => {
        if (heroButtons) {
            heroButtons.style.animation = 'fadeInUp 1s ease-out forwards';
        }
    }, 1200);

    setTimeout(() => {
        if (productShowcase) {
            productShowcase.style.animation = 'slideInRight 1s ease-out forwards';
        }
    }, 600);
}

// Utility Functions
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const offsetTop = section.offsetTop - 80;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

function playVideo() {
    alert('Video functionality would be implemented here!');
}

// Additional scroll effects
function setupScrollEffects() {
    const navbar = document.getElementById('navbar');
    let lastScrollTop = 0;

    window.addEventListener('scroll', function() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Navbar hide/show on scroll
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;

        // Parallax effect for floating elements
        const floatingElements = document.querySelectorAll('.floating-element');
        floatingElements.forEach((element, index) => {
            const speed = 0.5 + (index * 0.1);
            const yPos = -(scrollTop * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// Add CSS keyframes dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
`;
document.head.appendChild(style);