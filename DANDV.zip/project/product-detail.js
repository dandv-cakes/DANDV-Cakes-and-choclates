// WhatsApp Configuration
const WHATSAPP_NUMBER = '+919586386501'; // Replace with your actual WhatsApp number

// Global variables
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let currentProduct = null;

// Enhanced product data with detailed information
const products = [
    {
        id: 1,
        name: "Chocolate Delight Cake",
        price: 45.99,
        category: "cakes",
        images: [
            "https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Rich chocolate cake with layers of creamy ganache",
        fullDescription: "Indulge in our signature Chocolate Delight Cake, a masterpiece of rich, moist chocolate layers complemented by silky smooth ganache. Made with premium Belgian chocolate and fresh cream, this cake delivers an intense chocolate experience that melts in your mouth. Perfect for birthdays, celebrations, or when you simply crave the finest chocolate dessert.",
        ingredients: ["Premium Belgian Chocolate", "Fresh Cream", "Farm Fresh Eggs", "Pure Vanilla Extract", "Organic Flour", "Real Butter"],
        nutritionalInfo: {
            calories: "320 per slice",
            servings: "8-10 servings",
            weight: "2 lbs"
        },
        badge: "Bestseller",
        rating: 4.9,
        reviews: 156,
        sizes: [
            { name: "Small (6 inch)", price: 45.99 },
            { name: "Medium (8 inch)", price: 65.99 },
            { name: "Large (10 inch)", price: 85.99 }
        ]
    },
    {
        id: 2,
        name: "Vanilla Dream Cake",
        price: 39.99,
        category: "cakes",
        images: [
            "https://images.pexels.com/photos/140831/pexels-photo-140831.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1721932/pexels-photo-1721932.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Classic vanilla cake with buttercream frosting",
        fullDescription: "Our Vanilla Dream Cake is a timeless classic that never goes out of style. Made with real vanilla beans and topped with our signature buttercream frosting, this cake offers a perfect balance of sweetness and elegance. The moist, fluffy texture combined with the rich vanilla flavor makes it ideal for any celebration.",
        ingredients: ["Madagascar Vanilla Beans", "Fresh Buttercream", "Farm Fresh Eggs", "Organic Sugar", "Premium Flour", "Real Butter"],
        nutritionalInfo: {
            calories: "280 per slice",
            servings: "8-10 servings",
            weight: "1.8 lbs"
        },
        badge: "Popular",
        rating: 4.8,
        reviews: 134,
        sizes: [
            { name: "Small (6 inch)", price: 39.99 },
            { name: "Medium (8 inch)", price: 55.99 },
            { name: "Large (10 inch)", price: 75.99 }
        ]
    },
    {
        id: 3,
        name: "Strawberry Bliss",
        price: 42.99,
        category: "cakes",
        images: [
            "https://images.pexels.com/photos/827513/pexels-photo-827513.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1721932/pexels-photo-1721932.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Fresh strawberry cake with whipped cream",
        fullDescription: "Experience pure bliss with our Strawberry Cake, featuring layers of moist vanilla sponge filled with fresh strawberry compote and topped with light, airy whipped cream. Made with seasonal fresh strawberries, this cake captures the essence of summer in every bite.",
        ingredients: ["Fresh Strawberries", "Whipped Cream", "Vanilla Sponge", "Strawberry Compote", "Fresh Cream", "Natural Flavoring"],
        nutritionalInfo: {
            calories: "290 per slice",
            servings: "8-10 servings",
            weight: "1.9 lbs"
        },
        badge: "Seasonal",
        rating: 4.7,
        reviews: 98,
        sizes: [
            { name: "Small (6 inch)", price: 42.99 },
            { name: "Medium (8 inch)", price: 58.99 },
            { name: "Large (10 inch)", price: 78.99 }
        ]
    },
    {
        id: 4,
        name: "Premium Chocolate Box",
        price: 29.99,
        category: "chocolates",
        images: [
            "https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/3622643/pexels-photo-3622643.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Assorted premium chocolates in elegant packaging",
        fullDescription: "Our Premium Chocolate Box contains a carefully curated selection of handcrafted chocolates, each one a small work of art. From dark chocolate truffles to milk chocolate pralines, this collection showcases the finest cocoa beans from around the world, perfect for gifting or personal indulgence.",
        ingredients: ["Belgian Dark Chocolate", "Milk Chocolate", "Cocoa Butter", "Fresh Cream", "Natural Flavors", "Nuts & Fruits"],
        nutritionalInfo: {
            calories: "80 per piece",
            servings: "12 pieces",
            weight: "0.5 lbs"
        },
        badge: "Gift Box",
        rating: 4.9,
        reviews: 203,
        sizes: [
            { name: "Small Box (12 pieces)", price: 29.99 },
            { name: "Medium Box (24 pieces)", price: 54.99 },
            { name: "Large Box (36 pieces)", price: 79.99 }
        ]
    },
    {
        id: 5,
        name: "Dark Chocolate Truffles",
        price: 24.99,
        category: "chocolates",
        images: [
            "https://images.pexels.com/photos/3622643/pexels-photo-3622643.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Handcrafted dark chocolate truffles with ganache",
        fullDescription: "Indulge in our artisanal Dark Chocolate Truffles, each one hand-rolled and dusted with premium cocoa powder. Made with 70% dark chocolate and filled with silky ganache, these truffles offer an intense, sophisticated chocolate experience for the true connoisseur.",
        ingredients: ["70% Dark Chocolate", "Heavy Cream", "Cocoa Powder", "Vanilla Extract", "Sea Salt", "Natural Flavors"],
        nutritionalInfo: {
            calories: "95 per truffle",
            servings: "8 truffles",
            weight: "0.3 lbs"
        },
        badge: "Artisan",
        rating: 4.8,
        reviews: 87,
        sizes: [
            { name: "Box of 8", price: 24.99 },
            { name: "Box of 16", price: 44.99 },
            { name: "Box of 24", price: 64.99 }
        ]
    },
    {
        id: 6,
        name: "French Macarons",
        price: 18.99,
        category: "pastries",
        images: [
            "https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/827513/pexels-photo-827513.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        description: "Colorful French macarons with various flavors",
        fullDescription: "Transport yourself to Paris with our authentic French Macarons. These delicate almond-based cookies feature a crispy shell and chewy interior, filled with luxurious buttercream, ganache, or fruit preserves. Available in a rainbow of colors and flavors including vanilla, chocolate, raspberry, and pistachio.",
        ingredients: ["Almond Flour", "Egg Whites", "Sugar", "Food Coloring", "Buttercream", "Natural Flavors"],
        nutritionalInfo: {
            calories: "70 per macaron",
            servings: "6 macarons",
            weight: "0.2 lbs"
        },
        badge: "French",
        rating: 4.6,
        reviews: 76,
        sizes: [
            { name: "Box of 6", price: 18.99 },
            { name: "Box of 12", price: 34.99 },
            { name: "Box of 18", price: 49.99 }
        ]
    }
];

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeProductDetail();
    setupCartFunctionality();
    setupImageZoom();
});

function initializeProductDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id'));
    
    if (productId) {
        currentProduct = products.find(p => p.id === productId);
        if (currentProduct) {
            renderProductDetail(currentProduct);
            loadRelatedProducts(currentProduct);
        } else {
            // Redirect to home if product not found
            window.location.href = 'index.html';
        }
    } else {
        // Redirect to home if no product ID
        window.location.href = 'index.html';
    }
    
    updateCartDisplay();
}

function renderProductDetail(product) {
    const container = document.getElementById('product-detail-content');
    const breadcrumb = document.getElementById('breadcrumb-product');
    
    breadcrumb.textContent = product.name;
    document.title = `${product.name} - D&V Cakes and Chocolates`;
    
    container.innerHTML = `
        <div class="product-detail-grid">
            <div class="product-images">
                <div class="main-image">
                    <img src="${product.images[0]}" alt="${product.name}" id="main-product-image" class="zoomable">
                    ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
                </div>
                <div class="image-thumbnails">
                    ${product.images.map((img, index) => `
                        <img src="${img}" alt="${product.name}" class="thumbnail ${index === 0 ? 'active' : ''}" 
                             onclick="changeMainImage('${img}', ${index})">
                    `).join('')}
                </div>
            </div>
            
            <div class="product-info">
                <h1 class="product-title">${product.name}</h1>
                <div class="product-rating">
                    <div class="stars">
                        ${generateStars(product.rating)}
                    </div>
                    <span class="rating-text">${product.rating} (${product.reviews} reviews)</span>
                </div>
                
                <div class="product-price-section">
                    <span class="current-price" id="current-price">₹${product.price}</span>
                    <span class="price-note">Starting from</span>
                </div>
                
                <div class="product-description">
                    <p>${product.fullDescription}</p>
                </div>
                
                <div class="product-options">
                    <div class="size-selector">
                        <label>Size:</label>
                        <select id="size-select" onchange="updatePrice()">
                            ${product.sizes.map(size => `
                                <option value="${size.price}" data-name="${size.name}">${size.name} - ₹${size.price}</option>
                            `).join('')}
                        </select>
                    </div>
                    
                    <div class="quantity-selector">
                        <label>Quantity:</label>
                        <div class="quantity-controls">
                            <button type="button" onclick="changeQuantity(-1)">-</button>
                            <input type="number" id="quantity" value="1" min="1" max="10">
                            <button type="button" onclick="changeQuantity(1)">+</button>
                        </div>
                    </div>
                </div>
                
                <div class="product-actions">
                    <button class="btn btn-primary add-to-cart-btn" onclick="addToCartFromDetail()">
                        <i class="fas fa-shopping-cart"></i>
                        Add to Cart
                    </button>
                    <button class="btn btn-whatsapp" onclick="buyNowWhatsApp()">
                        <i class="fab fa-whatsapp"></i>
                        Buy Now via WhatsApp
                    </button>
                </div>
                
                <div class="product-details-tabs">
                    <div class="tab-buttons">
                        <button class="tab-btn active" onclick="showTab('ingredients')">Ingredients</button>
                        <button class="tab-btn" onclick="showTab('nutrition')">Nutrition</button>
                        <button class="tab-btn" onclick="showTab('reviews')">Reviews</button>
                    </div>
                    
                    <div class="tab-content">
                        <div id="ingredients-tab" class="tab-pane active">
                            <h4>Ingredients</h4>
                            <ul class="ingredients-list">
                                ${product.ingredients.map(ingredient => `<li>${ingredient}</li>`).join('')}
                            </ul>
                        </div>
                        
                        <div id="nutrition-tab" class="tab-pane">
                            <h4>Nutritional Information</h4>
                            <div class="nutrition-info">
                                <div class="nutrition-item">
                                    <span>Calories:</span>
                                    <span>${product.nutritionalInfo.calories}</span>
                                </div>
                                <div class="nutrition-item">
                                    <span>Servings:</span>
                                    <span>${product.nutritionalInfo.servings}</span>
                                </div>
                                <div class="nutrition-item">
                                    <span>Weight:</span>
                                    <span>${product.nutritionalInfo.weight}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div id="reviews-tab" class="tab-pane">
                            <h4>Customer Reviews</h4>
                            <div class="reviews-summary">
                                <div class="average-rating">
                                    <span class="rating-number">${product.rating}</span>
                                    <div class="stars">${generateStars(product.rating)}</div>
                                    <span class="total-reviews">${product.reviews} reviews</span>
                                </div>
                            </div>
                            <div class="sample-reviews">
                                <div class="review-item">
                                    <div class="reviewer-info">
                                        <strong>Sarah M.</strong>
                                        <div class="stars">${generateStars(5)}</div>
                                    </div>
                                    <p>"Absolutely delicious! The quality is outstanding and the taste is incredible."</p>
                                </div>
                                <div class="review-item">
                                    <div class="reviewer-info">
                                        <strong>John D.</strong>
                                        <div class="stars">${generateStars(5)}</div>
                                    </div>
                                    <p>"Perfect for our celebration. Everyone loved it!"</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHTML = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star"></i>';
    }
    
    return starsHTML;
}

function changeMainImage(imageSrc, index) {
    const mainImage = document.getElementById('main-product-image');
    const thumbnails = document.querySelectorAll('.thumbnail');
    
    mainImage.src = imageSrc;
    
    thumbnails.forEach((thumb, i) => {
        thumb.classList.toggle('active', i === index);
    });
}

function updatePrice() {
    const sizeSelect = document.getElementById('size-select');
    const currentPrice = document.getElementById('current-price');
    const selectedPrice = sizeSelect.value;
    
    currentPrice.textContent = `₹${selectedPrice}`;
}

function changeQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    let currentQuantity = parseInt(quantityInput.value);
    const newQuantity = currentQuantity + change;
    
    if (newQuantity >= 1 && newQuantity <= 10) {
        quantityInput.value = newQuantity;
    }
}

function showTab(tabName) {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabButtons.forEach(btn => btn.classList.remove('active'));
    tabPanes.forEach(pane => pane.classList.remove('active'));
    
    document.querySelector(`[onclick="showTab('${tabName}')"]`).classList.add('active');
    document.getElementById(`${tabName}-tab`).classList.add('active');
}

function addToCartFromDetail() {
    if (!currentProduct) return;
    
    const sizeSelect = document.getElementById('size-select');
    const quantityInput = document.getElementById('quantity');
    const selectedOption = sizeSelect.options[sizeSelect.selectedIndex];
    
    const cartItem = {
        id: currentProduct.id,
        name: currentProduct.name,
        price: parseFloat(sizeSelect.value),
        size: selectedOption.dataset.name,
        quantity: parseInt(quantityInput.value),
        image: currentProduct.images[0]
    };
    
    const existingItemIndex = cart.findIndex(item => 
        item.id === cartItem.id && item.size === cartItem.size
    );
    
    if (existingItemIndex > -1) {
        cart[existingItemIndex].quantity += cartItem.quantity;
    } else {
        cart.push(cartItem);
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
    showCartNotification(`${cartItem.name} (${cartItem.size}) added to cart!`);
}

// Show order modal
function showOrderModal(orderType) {
    document.getElementById('order-modal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
    document.getElementById('order-details-form').dataset.orderType = orderType;
}

// Hide order modal
document.getElementById('close-order-modal').onclick = function() {
    document.getElementById('order-modal').style.display = 'none';
    document.body.style.overflow = '';
};

// Handle form submit
document.getElementById('order-details-form').onsubmit = function(e) {
    e.preventDefault();
    const name = document.getElementById('order-name').value;
    const address = document.getElementById('order-address').value;
    const mobile = document.getElementById('order-mobile').value;
    const time = document.getElementById('order-time').value;
    const orderType = e.target.dataset.orderType;

    document.getElementById('order-modal').style.display = 'none';
    document.body.style.overflow = '';

    if (orderType === 'buyNow') {
        sendBuyNowWhatsApp(name, address, mobile, time);
    } else {
        sendCartWhatsApp(name, address, mobile, time);
    }
};

// Replace Buy Now and Checkout functions
function buyNowWhatsApp() {
    showOrderModal('buyNow');
}

function checkoutViaWhatsApp() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    showOrderModal('cart');
}

// Send WhatsApp for Buy Now
function sendBuyNowWhatsApp(name, address, mobile, time) {
    if (!currentProduct) return;
    const sizeSelect = document.getElementById('size-select');
    const quantityInput = document.getElementById('quantity');
    const selectedOption = sizeSelect.options[sizeSelect.selectedIndex];
    const quantity = parseInt(quantityInput.value);
    const price = parseFloat(sizeSelect.value);
    const total = (price * quantity).toFixed(2);

    const message = `🍰 *New Order from D&V Cakes & Chocolates*

📦 *Product:* ${currentProduct.name}
📏 *Size:* ${selectedOption.dataset.name}
🔢 *Quantity:* ${quantity}
💰 *Unit Price:* ₹${price}
💵 *Total Amount:* ₹${total}

📞 *Customer Details:*
• Name: ${name}
• Address: ${address}
• Mobile: ${mobile}
• Preferred Delivery Time: ${time}

Thank you for choosing D&V Cakes & Chocolates! 🎂✨`;

    const whatsappURL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, '_blank');
}

// Send WhatsApp for Cart Checkout
function sendCartWhatsApp(name, address, mobile, time) {
    let message = `🛒 *Order Summary from D&V Cakes & Chocolates*\n\n`;
    let total = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        message += `${index + 1}. *${item.name}*\n`;
        message += `   📏 Size: ${item.size || ''}\n`;
        message += `   🔢 Quantity: ${item.quantity}\n`;
        message += `   💰 Price: ₹${item.price} each\n`;
        message += `   💵 Subtotal: ₹${itemTotal.toFixed(2)}\n\n`;
    });

    message += `💵 *Total Amount: ₹${total.toFixed(2)}*\n\n`;
    message += `📞 *Customer Details:*\n`;
    message += `• Name: ${name}\n`;
    message += `• Address: ${address}\n`;
    message += `• Mobile: ${mobile}\n`;
    message += `• Preferred Delivery Time: ${time}\n\n`;
    message += `Thank you for choosing D&V Cakes & Chocolates! 🎂✨`;

    const whatsappURL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, '_blank');
}

function loadRelatedProducts(currentProduct) {
    const relatedGrid = document.getElementById('related-grid');
    const relatedProducts = products
        .filter(p => p.id !== currentProduct.id && p.category === currentProduct.category)
        .slice(0, 3);
    
    relatedGrid.innerHTML = relatedProducts.map(product => `
        <div class="related-product-card" onclick="goToProduct(${product.id})">
            <div class="related-product-image">
                <img src="${product.images[0]}" alt="${product.name}">
                ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
            </div>
            <div class="related-product-info">
                <h4>${product.name}</h4>
                <p class="related-product-price">₹${product.price}</p>
                <div class="related-product-rating">
                    ${generateStars(product.rating)}
                    <span>(${product.reviews})</span>
                </div>
            </div>
        </div>
    `).join('');
}

function goToProduct(productId) {
    window.location.href = `product-detail.html?id=${productId}`;
}

// Cart functionality
function setupCartFunctionality() {
    const cartIcon = document.getElementById('cart-icon');
    const cartSidebar = document.getElementById('cart-sidebar');
    const closeCart = document.getElementById('close-cart');
    const overlay = document.getElementById('overlay');

    cartIcon.addEventListener('click', openCart);
    closeCart.addEventListener('click', closeCartSidebar);
    overlay.addEventListener('click', closeCartSidebar);

    function openCart() {
        cartSidebar.classList.add('open');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeCartSidebar() {
        cartSidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }
}

function updateCartDisplay() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    cartCount.style.display = totalItems > 0 ? 'flex' : 'none';

    cartItems.innerHTML = '';
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 2rem;">Your cart is empty</p>';
    } else {
        cart.forEach((item, index) => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-size">${item.size}</div>
                    <div class="item-price">₹${item.price}</div>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="updateCartQuantity(${index}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateCartQuantity(${index}, 1)">+</button>
                    </div>
                </div>
                <button class="remove-item" onclick="removeFromCart(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            cartItems.appendChild(cartItem);
        });
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = total.toFixed(2);
}

function updateCartQuantity(index, change) {
    if (cart[index]) {
        cart[index].quantity += change;
        if (cart[index].quantity <= 0) {
            cart.splice(index, 1);
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartDisplay();
    }
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
}

// Image zoom functionality
function setupImageZoom() {
    const modal = document.getElementById('image-zoom-modal');
    const zoomedImage = document.getElementById('zoomed-image');
    const closeZoom = document.getElementById('close-zoom');

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('zoomable')) {
            modal.style.display = 'block';
            zoomedImage.src = e.target.src;
            zoomedImage.alt = e.target.alt;
        }
    });

    closeZoom.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
}